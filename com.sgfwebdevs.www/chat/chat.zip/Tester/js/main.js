$(function () {
    $(".users").select2();
    $(".open_users").select2({ tags: true, minimumResultsForSearch: Infinity });

    $('#open_session').change(function () {
        if ($(this).is(':checked')) {
            $('#open_attendees').removeAttr('disabled');
        } else {
            $('#open_attendees').prop('disabled', true);
        }
    });

    $('#start_immediately').change(function () {
        if ($(this).is(':checked')) {
            $('#start_at').prop('disabled', true);
        } else {
            $('#start_at').removeAttr('disabled');
        }
    });


    if ($('#start_at').attr('value')) {
        var date = $('#start_at').attr('value');

        $('#start_at').removeAttr('value');

        var dp = $('#start_at').datetimepicker({
            sideBySide: true,
            format: 'MM/DD/YY h:mm A',
            defaultDate: date
        });

    } else {
        var dp = $('#start_at').datetimepicker({
            sideBySide: true,
            format: 'MM/DD/YY h:mm A',
            useCurrent: true
        });
    }

    var calendar = $('#appointment-calendar').calendar({
        events_source: '/office/appointments/feed',
        tmpl_path: '/tmpls/'
    });

    $('.btn-group button[data-calendar-nav]').each(function () {
        var $this = $(this);
        $this.click(function () {
            calendar.navigate($this.data('calendar-nav'));
        });
    });

    $('.btn-group button[data-calendar-view]').each(function () {
        var $this = $(this);
        $this.click(function () {
            calendar.view($this.data('calendar-view'));
        });
    });


    checkClientEmail($('.email_check').val());
    $('.email_check').on('change', function() {
        checkClientEmail($(this).val());
    });

    function checkClientEmail(email) {
        if (email != '') {
            $.get('/office/clients/check', {email: email}, function (data) {
                if (data == 'true') {
                    $('input[type="password"]').not('.reset').val('').attr('disabled', 'disabled');
                    $('input[name="set_password"]').val('false');
                } else {
                    $('input[type="password"]').not('.reset').removeAttr('disabled');
                    $('input[name="set_password"]').val('true');
                }
            });
        }
    }
});